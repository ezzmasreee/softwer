package login;

import io.cucumber.java.en.*;

public class coustmer_login_steps {

@Given("Coustmer is not signed in")
public void coustmer_is_not_signed_in() {
    // Write code here that turns the phrase above into concrete actions
}

@When("The Coustmer enters valid email {string} and correct password {string}")
public void the_coustmer_enters_valid_email_and_correct_password(String string, String string2) {
    // Write code here that turns the phrase above into concrete actions
}

@Then("Coustmer enter to the system")
public void coustmer_enter_to_the_system() {
    // Write code here that turns the phrase above into concrete actions
}

@When("The Coustmer enters an invalid email {string}")
public void the_coustmer_enters_an_invalid_email(String string) {
    // Write code here that turns the phrase above into concrete actions
}

@Then("The Coustmer remain\\/still on the login page")
public void the_coustmer_remain_still_on_the_login_page() {
    // Write code here that turns the phrase above into concrete actions
}

@When("The Coustmer enters valid email {string} and incorrect password {string}")
public void the_coustmer_enters_valid_email_and_incorrect_password(String string, String string2) {
    // Write code here that turns the phrase above into concrete actions
}

@Then("The Coustmer will stay in login page")
public void the_coustmer_will_stay_in_login_page() {
    // Write code here that turns the phrase above into concrete actions
}



}
