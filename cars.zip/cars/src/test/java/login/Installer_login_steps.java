package login;

import io.cucumber.java.en.*;

public class Installer_login_steps {
	@Given("Installer is not signed in")
	public void installer_is_not_signed_in() {
	    // Write code here that turns the phrase above into concrete actions
	}

	@Then("Installer enter to the system")
	public void installer_enter_to_the_system() {
	    // Write code here that turns the phrase above into concrete actions
	}

	@When("The Installer enters an invalid email {string}")
	public void the_installer_enters_an_invalid_email(String string) {
	    // Write code here that turns the phrase above into concrete actions
	}

	@Then("The Installer remain\\/still on the login page")
	public void the_installer_remain_still_on_the_login_page() {
	    // Write code here that turns the phrase above into concrete actions
	}

	@When("The Installer enters valid email {string} and incorrect password {string}")
	public void the_installer_enters_valid_email_and_incorrect_password(String string, String string2) {
	    // Write code here that turns the phrase above into concrete actions
	}

	@Then("The Installer will stay in login page")
	public void the_installer_will_stay_in_login_page() {
	    // Write code here that turns the phrase above into concrete actions
	}

}
