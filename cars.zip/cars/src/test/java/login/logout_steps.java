package login;

import io.cucumber.java.en.*;

public class logout_steps {
	@Given("person is  signed in")
	public void person_is_signed_in() {
	    // Write code here that turns the phrase above into concrete actions
	}

	@When("The person said {string}")
	public void the_person_said(String string) {
	    // Write code here that turns the phrase above into concrete actions
	}

	@Then("person out  the system")
	public void person_out_the_system() {
	    // Write code here that turns the phrase above into concrete actions
	}


}
