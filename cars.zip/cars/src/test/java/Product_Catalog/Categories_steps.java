package Product_Catalog;

import io.cucumber.java.en.*;
public class Categories_steps {
	@Given("Admin is logged in")
	public void admin_is_logged_in() {
	    // Write code here that turns the phrase above into concrete actions
	    
	}

	@When("the Admin add a new name_product\"kia\" and key number {string} and price {string} and want to add categories {string}")
	public void the_admin_add_a_new_name_product_kia_and_key_number_and_price_and_want_to_add_categories(String string, String string2, String string3) {
	    // Write code here that turns the phrase above into concrete actions
	    
	}

	@Then("the categories product well add")
	public void the_categories_product_well_add() {
	    // Write code here that turns the phrase above into concrete actions
	    
	}
}