package User_Profile;

import io.cucumber.java.en.*;

public class ViewOrder_step {

	@Given("Coustmer is loggedin")
	public void coustmer_is_loggedin() {
	    // Write code here that turns the phrase above into concrete actions
	    
	}

	@When("The Coustmers want to see history and installation requests")
	public void the_coustmers_want_to_see_history_and_installation_requests() {
	    // Write code here that turns the phrase above into concrete actions
	    
	}

	@Then("the history appear")
	public void the_history_appear() {
	    // Write code here that turns the phrase above into concrete actions
	    
	}



}

