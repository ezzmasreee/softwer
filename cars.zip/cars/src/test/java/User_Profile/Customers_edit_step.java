package User_Profile;

import io.cucumber.java.en.*;

public class Customers_edit_step {

	@Given("Coustmer is signed_in")
	public void coustmer_is_signed_in() {
	    // Write code here that turns the phrase above into concrete actions
	    
	}

	@When("The Coustmer with email {string} and want to edit his phone to {string}")
	public void the_coustmer_with_email_and_want_to_edit_his_phone_to(String string, String string2) {
	    // Write code here that turns the phrase above into concrete actions
	    
	}

	@Then("Coustmer edit successfuly")
	public void coustmer_edit_successfuly() {
	    // Write code here that turns the phrase above into concrete actions
	    
	}

	@Then("The system give message {string}")
	public void the_system_give_message(String string) {
	    // Write code here that turns the phrase above into concrete actions
	    
	}


}

