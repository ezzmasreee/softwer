package admin_dashboard;

import io.cucumber.java.en.*;

public class admin_deleteproduct_steps {
	@When("the Admin delete a product by key number'{int}'")
	public void the_admin_delete_a_product_by_key_number(Integer key_number) {
	    // Write code here that turns the phrase above into concrete actions
	}

	@Then("the  product well delete")
	public void the_product_well_delete() {
	    // Write code here that turns the phrase above into concrete actions
	}


}
