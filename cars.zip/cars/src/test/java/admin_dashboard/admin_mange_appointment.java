package admin_dashboard;

import io.cucumber.java.en.*;

public class admin_mange_appointment {
	@When("the Admin  well have a what time the appointment {string}")
public void the_admin_well_have_a_what_time_the_appointment(String string) {
    // Write code here that turns the phrase above into concrete actions
}

@Then("the  admin well dicide yes or no")
public void the_admin_well_dicide_yes_or_no() {
    // Write code here that turns the phrase above into concrete actions
}


}
