package admin_dashboard;

import io.cucumber.java.en.*;

public class admin_addproduct_steps {
	@Given("Admin is sign in")
	public void admin_is_sign_in() {
	    // Write code here that turns the phrase above into concrete actions

	}

	@When("the Admin add a new name_product\"kia\" and key number {string} and price \"{int}'")
	public void the_admin_add_a_new_name_product_kia_and_key_number_and_price(String string, Integer int1) {
	    // Write code here that turns the phrase above into concrete actions
	}

	@Then("the new product well add")
	public void the_new_product_well_add() {
	    // Write code here that turns the phrase above into concrete actions
	}
}
