package admin_dashboard;

import io.cucumber.java.en.*;

public class admin_updatelist_steps {
	@When("the Admin update  listing by key'{int}' and list name {string}")
	public void the_admin_update_listing_by_key_and_list_name(Integer key, String name) {
	    // Write code here that turns the phrase above into concrete actions
	}

	@Then("the  listing well update")
	public void the_listing_well_update() {
	    // Write code here that turns the phrase above into concrete actions
	}

}
