package admin_dashboard;

import io.cucumber.java.en.*;

public class admin_viewcoustmer_steps {
	@When("the Admin search coustmer by email {string}")
	public void the_admin_search_coustmer_by_email(String string) {
	    // Write code here that turns the phrase above into concrete actions
	}

	@Then("the  coustmer well show")
	public void the_coustmer_well_show() {
	    // Write code here that turns the phrase above into concrete actions
	}

}
