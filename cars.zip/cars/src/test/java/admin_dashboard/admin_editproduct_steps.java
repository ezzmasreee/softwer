package admin_dashboard;

import io.cucumber.java.en.*;

public class admin_editproduct_steps {
	@When("the Admin edit a new name_product {string} and key number {int} and price \"{int}'")
	public void the_admin_edit_a_new_name_product_kia_and_key_number_and_price(String name,int key_number, int price) {
	    // Write code here that turns the phrase above into concrete actions
	}

	@Then("the  product well update")
	public void the_product_well_update() {
	    // Write code here that turns the phrase above into concrete actions
	}
}
