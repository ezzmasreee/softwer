package admin_dashboard;

import io.cucumber.java.en.*;

public class admin_manage_coustmer_steps {
	@When("the Admin search coustmer by email {string} and want change his place {string}")
	public void the_admin_search_coustmer_by_email_and_want_change_his_place(String string, String string2) {
	    // Write code here that turns the phrase above into concrete actions
	}

	@Then("the  costmer have new data")
	public void the_costmer_have_new_data() {
	    // Write code here that turns the phrase above into concrete actions
	}
}
