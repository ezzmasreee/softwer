package product;

public class categories {
	String categ=new String();
	public void set_categories(String a) {
		categ=a;
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String a= new String(); a="ezz";
		String b=new String();
		b=a;
System.out.print(b);
	}

}
