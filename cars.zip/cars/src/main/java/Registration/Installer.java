package Registration;

public class Installer {
	String name;
	String email;
	String password;
	Installer(String a,String b,	String c){
		name=a;
		email=b;
		password=c;
	}


	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
